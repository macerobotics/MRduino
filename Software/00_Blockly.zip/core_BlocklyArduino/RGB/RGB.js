var name="RGB";
function embedswf()
{
	document.write('<APPLET CODE="'+ name +'.class" WIDTH="500" HEIGHT="250">Votre navigateur n\'est pas compatible Java.</APPLET>');
}